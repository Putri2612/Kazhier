<div class="container">
    <nav class="row navbar navbar-expand-lg navbar-light bg-white">
        <div class="navbar-nav ml-auto mr-auto mr-sm-auto mr-lg-0 mr-md-auto">
            <a href="{{route('dashboard')}}" class="navbar-brand">
        
            </a>
        </div>
         
    </nav>
</div>
<main>
    <div class="section-success d-flex align-items-center">
        <div class="col text-center">
                   
            <h1>
                Oops
            </h1>
            <p>
               Your Transaction is Failed
                <br />
               please contact us this problem occurs
            </p>
            <a href="{{route('dashboard')}}" class="btn btn-home-page mt-3 px-5">
                Home Page
            </a>
        </div>
    </div>
</main>